//
//  ViewController.swift
//  Lamont_Conor_WarApp
//
//  Created by Period Two on 2018-11-12.
//  Copyright © 2018 Period Two. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //The following lines declare variables or connect an outlet to the mainstoryboard
    // 2 image views
    @IBOutlet weak var leftCardImage: UIImageView!
    @IBOutlet weak var rightCardImage: UIImageView!
    
    
    // Total score labels
    @IBOutlet weak var leftPlayerLabel: UILabel!
    @IBOutlet weak var rightPlayerLabel: UILabel!
    
    // Draw button
    @IBOutlet weak var playCardsButton: UIButton!
    
    // War Images
    @IBOutlet weak var leftPlayer2: UIImageView!
    @IBOutlet weak var leftPlayer3: UIImageView!
    @IBOutlet weak var leftPlayer4: UIImageView!
    @IBOutlet weak var rightPlayer2: UIImageView!
    @IBOutlet weak var rightPlayer3: UIImageView!
    @IBOutlet weak var rightPlayer4: UIImageView!
    // Outlet for the button to create a new game
    @IBOutlet weak var newGameButton: UIButton!
    //The Labels with the war values
    @IBOutlet weak var leftWarLabel: UILabel!
    @IBOutlet weak var rightWarLabel: UILabel!
    
    
    
    
    @IBOutlet weak var player2Label2: UILabel!
    @IBOutlet weak var player2Label3: UILabel!
    @IBOutlet weak var player2Label4: UILabel!
    
    
    
    @IBOutlet weak var player1Label2: UILabel!
    @IBOutlet weak var player1Label3: UILabel!
    @IBOutlet weak var player1Label4: UILabel!
    
    
    
    //String For whichever player won, and the difference between scores
    var winnerPlayer : String = ""
    var playerScoreDifference = 0
    
    
    //Creates an empty dictionary later used for card images and their values
    var cardDeckDictionary: [UIImage: Int] = [:]
    // Creates an image deck which will be shuffled
    var imageDeck: [UIImage] = []
    //the player 1 and 2 total scores
    var player1Score: Int = 0
    var player2Score: Int = 0
    
    //The values for war cards
    var player1Value2 = 0
    var player1Value3 = 0
    var player1Value4 = 0
    var player2Value2 = 0
    var player2Value3 = 0
    var player2Value4 = 0
    
    //The values for the current cards being played at the top
    var currentCard1 : Int = 0
    var currentCard2 : Int = 0
    
    // The upper limit and random number for the shuffle routine
    var upperLimit = 51
    var randomNumber: Int = 0
    
    // The deck of player cards, or the shuffled deck of images
    var playerDeck: [UIImage] = []
    
    
    //This function will return end game values of which player won, and the difference between the 2
    func endGamevalues (player1Score: Int, player2Score: Int) -> (Int, String) {
        //The winner player will be  a string of whichever player won, and the difference will be the greater score - the lesser score
        if player1Score > player2Score {
            winnerPlayer = "Player 1"
            playerScoreDifference = player1Score - player2Score
        }else if player2Score > player1Score {
            winnerPlayer = "Player 2"
            playerScoreDifference = player2Score - player1Score
        }else {
            winnerPlayer = "Nobody"
            playerScoreDifference = 0
        }
        return (playerScoreDifference, winnerPlayer)
    }
    
    
    
    
    //The labels for the war values will be hidden in this function
    func showWarLabels () {
        leftWarLabel.isHidden = false
        rightWarLabel.isHidden = false
    }
    //The labels for the war values will be hidden in this function
    func hideWarLabels () {
        leftWarLabel.isHidden = true
        rightWarLabel.isHidden = true
    }
    
    
    func hideIndividualwarLabels () {
        player1Label2.isHidden = true
        player1Label3.isHidden = true
        player1Label4.isHidden = true
        player2Label2.isHidden = true
        player2Label3.isHidden = true
        player2Label4.isHidden = true
    }
    
    
    
    
    
    //these function show the individual war labels, which will display scores, there are three for the three types of war
        func individualwarLabels () {
            player1Label2.isHidden = false
            player1Label3.isHidden = false
            player1Label4.isHidden = false
            player2Label2.isHidden = false
            player2Label3.isHidden = false
            player2Label4.isHidden = false
    }
    func individualWarLabel2() {
        player1Label2.isHidden = false
        player1Label3.isHidden = false
        player2Label2.isHidden = false
        player2Label3.isHidden = false
    }
    func individualWarLabels3(){
           player1Label2.isHidden = false
        player2Label2.isHidden = false
    }
    
    
    // This function will reset all values necessary to start a new game, including the dictionary for the dicitionary, the unshuffled and shuffled image array, the player 1 and two scores, hide the war images, reset the top 2 war images, and reset the upper limit for the shuffle routine, and it will re-do my shuffle routine
    func newGame (){
        cardDeckDictionary = //SPADES, CLUBS, HEARTS, DIAMOND
            [#imageLiteral(resourceName: "AS.jpg") :14,#imageLiteral(resourceName: "KS.jpg") : 13, #imageLiteral(resourceName: "QS.jpg") : 12,#imageLiteral(resourceName: "JS.jpg") : 11, #imageLiteral(resourceName: "10S.jpg") : 10, #imageLiteral(resourceName: "9S.jpg") : 9,#imageLiteral(resourceName: "8S.jpg") : 8,#imageLiteral(resourceName: "7S.jpg") : 7,#imageLiteral(resourceName: "6S.jpg") : 6, #imageLiteral(resourceName: "5S.jpg") : 5,#imageLiteral(resourceName: "4S.jpg") : 4, #imageLiteral(resourceName: "3S.jpg") : 3,#imageLiteral(resourceName: "2S.jpg") : 2,#imageLiteral(resourceName: "AC.jpg"): 14,#imageLiteral(resourceName: "KC.jpg") : 13, #imageLiteral(resourceName: "QC.jpg"): 12,#imageLiteral(resourceName: "JC.jpg") : 11, #imageLiteral(resourceName: "10C.jpg"): 10,#imageLiteral(resourceName: "9C.jpg") : 9,#imageLiteral(resourceName: "8C.jpg") : 8,#imageLiteral(resourceName: "7C.jpg") : 7,#imageLiteral(resourceName: "6C.jpg") : 6, #imageLiteral(resourceName: "5C.jpg"): 5, #imageLiteral(resourceName: "4C.jpg"): 4,#imageLiteral(resourceName: "3C.jpg"): 3, #imageLiteral(resourceName: "2C.jpg"): 2,#imageLiteral(resourceName: "AH.jpg"): 14,#imageLiteral(resourceName: "KH.jpg") : 13, #imageLiteral(resourceName: "QH.jpg"): 12, #imageLiteral(resourceName: "JH.jpg"): 11, #imageLiteral(resourceName: "10H.jpg"): 10,#imageLiteral(resourceName: "9H.jpg") : 9,#imageLiteral(resourceName: "8H.jpg") : 8,#imageLiteral(resourceName: "7H.jpg") : 7, #imageLiteral(resourceName: "6H.jpg"): 6, #imageLiteral(resourceName: "5H.jpg"): 5,#imageLiteral(resourceName: "4H.jpg") : 4, #imageLiteral(resourceName: "3H.jpg"): 3,#imageLiteral(resourceName: "2H.jpg") : 2,#imageLiteral(resourceName: "AD.jpg"): 14, #imageLiteral(resourceName: "KD.jpg"): 13, #imageLiteral(resourceName: "QD.jpg"): 12, #imageLiteral(resourceName: "JD.jpg"): 11,#imageLiteral(resourceName: "10D.jpg") : 10, #imageLiteral(resourceName: "9D.jpg"): 9,#imageLiteral(resourceName: "8D.jpg") : 8,#imageLiteral(resourceName: "7D.jpg") : 7, #imageLiteral(resourceName: "6D.jpg"): 6,#imageLiteral(resourceName: "5D.jpg") : 5,#imageLiteral(resourceName: "4D.jpg") : 4, #imageLiteral(resourceName: "3D.jpg"): 3, #imageLiteral(resourceName: "2D"): 2]
        imageDeck = Array(cardDeckDictionary.keys)
        player1Score = 0
        player2Score = 0
        hideImages()
        playCardsButton.isEnabled = true
        upperLimit = 51
        leftCardImage.image = #imageLiteral(resourceName: "Red_back.jpg")
        rightCardImage.image = #imageLiteral(resourceName: "Red_back.jpg")
        for _ in 0...51 {
            randomNumber = Int.random(in: 0...upperLimit)
            playerDeck.append(imageDeck[randomNumber])
            imageDeck.remove(at: randomNumber)
            upperLimit -= 1
        }
        playCardsButton.isEnabled = true
        newGameButton.isEnabled = false
        hideIndividualwarLabels()
        hideWarLabels()
    }
    
    

    override func viewDidLoad() {
        //This dictionary assigns the images to an integer value
        cardDeckDictionary = //SPADES, CLUBS, HEARTS, DIAMOND
            [#imageLiteral(resourceName: "AS.jpg") :14,#imageLiteral(resourceName: "KS.jpg") : 13, #imageLiteral(resourceName: "QS.jpg") : 12,#imageLiteral(resourceName: "JS.jpg") : 11, #imageLiteral(resourceName: "10S.jpg") : 10, #imageLiteral(resourceName: "9S.jpg") : 9,#imageLiteral(resourceName: "8S.jpg") : 8,#imageLiteral(resourceName: "7S.jpg") : 7,#imageLiteral(resourceName: "6S.jpg") : 6, #imageLiteral(resourceName: "5S.jpg") : 5,#imageLiteral(resourceName: "4S.jpg") : 4, #imageLiteral(resourceName: "3S.jpg") : 3,#imageLiteral(resourceName: "2S.jpg") : 2,#imageLiteral(resourceName: "AC.jpg"): 14,#imageLiteral(resourceName: "KC.jpg") : 13, #imageLiteral(resourceName: "QC.jpg"): 12,#imageLiteral(resourceName: "JC.jpg") : 11, #imageLiteral(resourceName: "10C.jpg"): 10,#imageLiteral(resourceName: "9C.jpg") : 9,#imageLiteral(resourceName: "8C.jpg") : 8,#imageLiteral(resourceName: "7C.jpg") : 7,#imageLiteral(resourceName: "6C.jpg") : 6, #imageLiteral(resourceName: "5C.jpg"): 5, #imageLiteral(resourceName: "4C.jpg"): 4,#imageLiteral(resourceName: "3C.jpg"): 3, #imageLiteral(resourceName: "2C.jpg"): 2,#imageLiteral(resourceName: "AH.jpg"): 14,#imageLiteral(resourceName: "KH.jpg") : 13, #imageLiteral(resourceName: "QH.jpg"): 12, #imageLiteral(resourceName: "JH.jpg"): 11, #imageLiteral(resourceName: "10H.jpg"): 10,#imageLiteral(resourceName: "9H.jpg") : 9,#imageLiteral(resourceName: "8H.jpg") : 8,#imageLiteral(resourceName: "7H.jpg") : 7, #imageLiteral(resourceName: "6H.jpg"): 6, #imageLiteral(resourceName: "5H.jpg"): 5,#imageLiteral(resourceName: "4H.jpg") : 4, #imageLiteral(resourceName: "3H.jpg"): 3,#imageLiteral(resourceName: "2H.jpg") : 2,#imageLiteral(resourceName: "AD.jpg"): 14, #imageLiteral(resourceName: "KD.jpg"): 13, #imageLiteral(resourceName: "QD.jpg"): 12, #imageLiteral(resourceName: "JD.jpg"): 11,#imageLiteral(resourceName: "10D.jpg") : 10, #imageLiteral(resourceName: "9D.jpg"): 9,#imageLiteral(resourceName: "8D.jpg") : 8,#imageLiteral(resourceName: "7D.jpg") : 7, #imageLiteral(resourceName: "6D.jpg"): 6,#imageLiteral(resourceName: "5D.jpg") : 5,#imageLiteral(resourceName: "4D.jpg") : 4, #imageLiteral(resourceName: "3D.jpg"): 3, #imageLiteral(resourceName: "2D"): 2]
        //The keys from the dicionary are assigned to an array of images which is the imageDeck
        imageDeck = Array(cardDeckDictionary.keys)
        
        
        //This shuffle routine will take the images form imageDeck and place them in a shuffled deck of images called playerDeck
        for _ in 0...51 {
            randomNumber = Int.random(in: 0...upperLimit)
            playerDeck.append(imageDeck[randomNumber])
            imageDeck.remove(at: randomNumber)
            upperLimit -= 1
        }
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
}
    //This function hides all war images
    func hideImages () {
        leftPlayer2.isHidden = true
        leftPlayer3.isHidden = true
        leftPlayer4.isHidden = true
        rightPlayer2.isHidden = true
        rightPlayer3.isHidden = true
        rightPlayer4.isHidden = true
        
    }
    //this function reveals all war images
    func showImages (){
        leftPlayer2.isHidden = false
        leftPlayer3.isHidden = false
        leftPlayer4.isHidden = false
        rightPlayer2.isHidden = false
        rightPlayer3.isHidden = false
        rightPlayer4.isHidden = false
    }
    
    
    //The following button is to draw cards and play the game
    @IBAction func actionPlayCards(_ sender: Any) {
        //Every time the button is pressed, the war images and labels are hidden, which will then be revealed if there ends up being a war
        hideWarLabels()
        hideIndividualwarLabels()
        hideImages()
        // The following lines animate the images every time they are drawn
        UIView.transition(with: leftCardImage, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
        UIView.transition(with: rightCardImage, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
        
        // this assigns the first and second element form player deck to the top 2 images
        leftCardImage.image = playerDeck[0]
        rightCardImage.image = playerDeck[1]
        
        //These 2 lines remove the 2 images from the top 2 images and stores them in firstCard and secondCard, the reason they are both "at: 0" is because once the zero value is removed, the element that was previously the 1 index becomes the 0 index
        let firstCard = playerDeck.remove(at: 0)
        let secondCard = playerDeck.remove(at: 0)
        
        //These if let statements will take the images from the top 2imagesviews, searches them up in the dictionary, removes the values assigned to those images and assigns them to currentCard1 and currentcard2 which can be used outside of these statements
        if let number1 = cardDeckDictionary.removeValue(forKey: firstCard){
            currentCard1 = number1
        }
        if let number2 = cardDeckDictionary.removeValue(forKey: secondCard){
            currentCard2 = number2
            hideImages()
        }
        
        //The following if statements add to the player scoring based off whichever card value is larger, and adding 2 to whoever won, in the first statement player 1 wins 2 points if he has a higher score
        if currentCard1 > currentCard2 {
            player1Score += 2
            hideImages()
        }// this statement will add 2 to player2Score if their card value is higher
        else if currentCard2 > currentCard1 {
            player2Score += 2
        }
            //This is the first part of the war statement, assuming the card values are equal and the card deck has 6 or more cards left, meaning a full war can still happen
        else if currentCard1 == currentCard2 && playerDeck.count >= 6 {
            //The following lines reveal all the war images and does a transition for the animation
            showImages()
            
            
            UIView.transition(with: leftPlayer2, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: leftPlayer3, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: leftPlayer4, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: rightPlayer2, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: rightPlayer3, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: rightPlayer4, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            
            //These lines assign the next 6 cards in the deckto the 6 war image views
            leftPlayer2.image = playerDeck[0]
            leftPlayer3.image = playerDeck[1]
            leftPlayer4.image = playerDeck[2]
            rightPlayer2.image = playerDeck[3]
            rightPlayer3.image = playerDeck[4]
            rightPlayer4.image = playerDeck[5]
            
            //These lines remove the images for the 6 cards in the war from the shuffled deck
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            
            //This code assigns the images from the wars to constants
            let player1Image2 = leftPlayer2.image
            let player1Image3 = leftPlayer3.image
            let player1Image4 = leftPlayer4.image
            let player2Image2 = rightPlayer2.image
            let player2Image3 = rightPlayer3.image
            let player2Image4 = rightPlayer4.image
            
            // These if let statements search the war images in the dictionary, and assign the values to constants
            if let player1SecondValue = cardDeckDictionary.removeValue(forKey: player1Image2!){
                player1Value2 = player1SecondValue
            }
            if let player1ThirdValue = cardDeckDictionary.removeValue(forKey: player1Image3!){
                player1Value3 = player1ThirdValue
            }
            if let player1FourthValue = cardDeckDictionary.removeValue(forKey: player1Image4!){
                player1Value4 = player1FourthValue
            }
            if let player2SecondValue = cardDeckDictionary.removeValue(forKey: player2Image2!){
                player2Value2 = player2SecondValue
            }
            if let player2ThirdValue = cardDeckDictionary.removeValue(forKey: player2Image3!){
                player2Value3 = player2ThirdValue
            }
            if let player2FourthValue = cardDeckDictionary.removeValue(forKey: player2Image4!){
                player2Value4 = player2FourthValue
            }
            
            
            //The following lines show the individual war labels and scores
            individualwarLabels()
            player1Label2.text = String(player1Value2)
            player1Label3.text = String(player1Value3)
            player1Label4.text = String(player1Value4)
            player2Label2.text = String(player2Value2)
            player2Label3.text = String(player2Value3)
            player2Label4.text = String(player2Value4)
            
            //These if statements compare the sum of the player 1 total for war and player2 2 total for war and gives to points to whoever won the war, or if the war is tied each player gets 1 point
            if (player1Value2 + player1Value3 + player1Value4) > (player2Value2 + player2Value3 + player2Value4){
                player1Score += 2
            }else if (player2Value2 + player2Value3 + player2Value4) > (player1Value2 + player1Value3 + player1Value4){
                player2Score += 2
            }else {
                player1Score += 1
                player2Score += 1
            }
            
            //The following lines show the war labels and have the total war value inside them
            showWarLabels()
            rightWarLabel.text = "Player 2 war total: \(player2Value2 + player2Value3 + player2Value4)"
            leftWarLabel.text = "Player 1 war total: \(player1Value2 + player1Value3 + player1Value4)"
            // end of the first war segment
        }
            
            //This statement will produce 4 images for the war instead of six, assuming the deck count is 4 or 5, although in reality it will only be 4
        else if currentCard1 == currentCard2 && playerDeck.count < 6 && playerDeck.count > 3 {
            //The following lines reveal all the war images and does a transition for the animation
            leftPlayer2.isHidden = false
            leftPlayer3.isHidden = false
            rightPlayer2.isHidden = false
            rightPlayer3.isHidden = false
            UIView.transition(with: leftPlayer2, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: leftPlayer3, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: rightPlayer2, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: rightPlayer3, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            
            
            //These lines assign the next 4 cards in the deckto the 4 war image views
            leftPlayer2.image = playerDeck[0]
            leftPlayer3.image = playerDeck[1]
            rightPlayer2.image = playerDeck[2]
            rightPlayer3.image = playerDeck[3]
            
            //These lines remove the images for the 4 cards in the war from the shuffled deck
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
            
            //This code assigns the images from the wars to constants
            let player1Image2 = leftPlayer2.image
            let player1Image3 = leftPlayer3.image
            let player2Image2 = rightPlayer2.image
            let player2Image3 = rightPlayer3.image
            
            
            // These if let statements search the war images in the dictionary, and assign the values to constants
            if let player1SecondValue = cardDeckDictionary.removeValue(forKey: player1Image2!){
                player1Value2 = player1SecondValue
            }
            if let player1ThirdValue = cardDeckDictionary.removeValue(forKey: player1Image3!){
                player1Value3 = player1ThirdValue
            }
            if let player2SecondValue = cardDeckDictionary.removeValue(forKey: player2Image2!){
                player2Value2 = player2SecondValue
            }
            if let player2ThirdValue = cardDeckDictionary.removeValue(forKey: player2Image3!){
                player2Value3 = player2ThirdValue
            }
            
            //The following lines show the individual war labels and scores
            individualWarLabel2()
            player1Label2.text = String(player1Value2)
            player1Label3.text = String(player1Value3)
            player2Label2.text = String(player2Value2)
            player2Label3.text = String(player2Value3)
            
            
            //These if statements compare the sum of the player 1 total for war and player2 2 total for war and gives to points to whoever won the war, or if the war is tied each player gets 1 point
            if (player1Value2 + player1Value3) > (player2Value2 + player2Value3){
                player1Score += 2
            }else if (player2Value2 + player2Value3) > (player1Value2 + player1Value3) {
                player2Score += 2
            }else {
                player1Score += 1
                player2Score += 1
            }
            
            
            //The following lines show the war labels and have the total war value inside them
            showWarLabels()
            rightWarLabel.text = "Player 2 war total:\(player2Value2 + player2Value3)"
            leftWarLabel.text =  "Player 1 war total: \(player1Value2 + player1Value3)"
            
            //end of second war segment
        }
            
            
            
            
            
            //This statement will produce 2 images for the war instead of six, assuming the deck count is 2 or 3, although in reality it will only be 2
        else if currentCard1 == currentCard2 && playerDeck.count < 4 && playerDeck.count > 1 {
            
            //The following lines reveal all the war images and does a transition for the animation
            leftPlayer2.isHidden = false
            rightPlayer2.isHidden = false
            UIView.transition(with: leftPlayer2, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            UIView.transition(with: rightPlayer2, duration: 0.5, options: .transitionFlipFromTop, animations: nil, completion: nil)
            
            
            
            //These lines assign the next 2 cards in the deck to the 2 war image views
            leftPlayer2.image = playerDeck[0]
            rightPlayer2.image = playerDeck[1]
            
            //These lines remove the images for the 2 cards in the war from the shuffled deck
            playerDeck.remove(at: 0)
            playerDeck.remove(at: 0)
        
            //This code assigns the images from the wars to constants
            let player1Image2 = leftPlayer2.image
            let player2Image2 = rightPlayer2.image
            
            // These if let statements search the war images in the dictionary, and assign the values to constants
            if let player1SecondValue = cardDeckDictionary.removeValue(forKey: player1Image2!){
                player1Value2 = player1SecondValue
            }
            if let player2SecondValue = cardDeckDictionary.removeValue(forKey: player2Image2!){
                player2Value2 = player2SecondValue
            }
            //The following lines show the individual war labels and scores
            individualWarLabels3()
            player1Label2.text = String(player1Value2)
            player2Label2.text = String(player2Value2)
            
            
            
            
            //These if statements compare the sum of the player 1 total for war and player2 2 total for war and gives to points to whoever won the war, or if the war is tied each player gets 1 point
            if player1Value2 > player2Value2 {
                player1Score += 2
            }else if player2Value2 > player1Value2 {
                player2Score += 2
            }else {
                player1Score += 1
                player2Score += 1
            }
            
            //The following lines show the war labels and have the total war value inside them
            showWarLabels()
            rightWarLabel.text = "Player 2 war total: \(player2Value2)"
            leftWarLabel.text = "Player 1 war total: \(player1Value2)"
        }// this war funtion is designed for a war with 0 cards left, and gives both player 1 point
        else if currentCard1 == currentCard2 && playerDeck.count == 0{
            player1Score += 1
            player2Score += 1
            //end of all war functions
        }
        
        
        
        //the following code fills the players score labels text with their actual score
        leftPlayerLabel.text = ("Player 1 Score: \(String(player1Score))")
        rightPlayerLabel.text = ("Player 2 Score: \(String(player2Score))")
        
        //The following if statement will disable the draw button and enable the new game button and have the alert box pop up to start a new game
        if playerDeck.count == 0 {
            let finishingTouches  = endGamevalues(player1Score: player1Score, player2Score: player2Score)
            
            newGameButton.isEnabled = true
            playCardsButton.isEnabled = false
            let alert = UIAlertController(title: "Do you want to play again?", message: "C'mon, 1 more game! \(finishingTouches.1) won by a score of \(finishingTouches.0). Press Yes then new game to start it up.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        print("first card is \(currentCard1)")
        print("second card is \(currentCard2)")
        
    }
    
    // The following button is the new game button
    @IBAction func newGameAction(_ sender: Any) {
        //This code starts a new game every time new game button is presed, and immediately sets the player score labels to 0
        newGame()
        leftPlayerLabel.text = "Player 1 Score: 0"
        rightPlayerLabel.text = "Player 2 Score: 0"
    }
}

